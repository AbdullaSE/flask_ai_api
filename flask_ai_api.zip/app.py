from flask import Flask, request, jsonify
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

app = Flask(__name__)

# تدريب النموذج
def train_model():
    data = {
        'معدل التوجيهي': [90, 85, 75, 95, 80],
        'نوع الثانوية': ['علمي', 'أدبي', 'علمي', 'أدبي', 'علمي'],
        'المواد المفضلة': ['الرياضيات', 'اللغة العربية', 'الفيزياء', 'الرياضيات', 'اللغة الإنجليزية'],
        'أفضل التخصصات': ['الهندسة', 'الطب', 'الهندسة', 'العلوم السياسية', 'الطب'],
        'نمط العمل المفضل': ['مكتبي', 'ميداني', 'ميداني', 'مكتبي', 'مكتبي'],
        'الهوايات_المهارات': ['برمجة', 'كتابة', 'مغامرة', 'برمجة', 'قراءة'],
        'الوظيفة_أو_المجال_الحلمي': ['مطور برمجيات', 'طبيب', 'مهندس', 'صحفي', 'مطور برمجيات'],
        'التخصص المختار': ['هندسة البرمجيات', 'الطب', 'هندسة البرمجيات', 'العلوم السياسية', 'الطب']
    }

    df = pd.DataFrame(data)

    label_encoders = {}
    for col in df.columns[:-1]:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])
        label_encoders[col] = le

    X = df.drop('التخصص المختار', axis=1)
    y = df['التخصص المختار']

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, y)

    return model, label_encoders

model, label_encoders = train_model()

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    input_data = {}

    try:
        for feature in data:
            if feature in label_encoders:
                le = label_encoders[feature]
                value = data[feature]

                if value in le.classes_:
                    input_data[feature] = le.transform([value])
                else:
                    return jsonify({'error': f"القيمة '{value}' غير موجودة في بيانات التدريب لعنصر '{feature}'"}), 400
            else:
                return jsonify({'error': f"العنصر '{feature}' غير معروف"}), 400

        input_df = pd.DataFrame(input_data)
        prediction = model.predict(input_df)
        predicted_specialization = prediction[0]

        return jsonify({'predicted_specialization': predicted_specialization})

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)